<?php

/* /views/pages/view.twig */
class __TwigTemplate_3b74b4a7dd82d2d77fbe0a196c012fdd29713363138d5b4674acd37d7e1807bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
";
        // line 2
        $this->displayBlock('title', $context, $blocks);
        // line 3
        $this->displayBlock('content', $context, $blocks);
        echo " 


";
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Меняю заголовок страницы";
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        echo "Как бодрость духа?";
    }

    public function getTemplateName()
    {
        return "/views/pages/view.twig";
    }

    public function getDebugInfo()
    {
        return array (  40 => 3,  34 => 2,  26 => 3,  24 => 2,  21 => 1,);
    }
}
