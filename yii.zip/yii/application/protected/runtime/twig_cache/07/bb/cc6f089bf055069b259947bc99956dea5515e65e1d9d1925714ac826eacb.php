<?php

/* /views//layouts/main.twig */
class __TwigTemplate_07bbcc6f089bf055069b259947bc99956dea5515e65e1d9d1925714ac826eacb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
<!doctype html>
<html class=\"no-js\" lang=\"en\">
  <head>
    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
    <title>Foundation | Welcome</title>
    <link rel=\"stylesheet\" href=\"zurb/css/foundation.css\" />
    <script src=\"zurb/js/modernizr.js\"></script>
  </head>
  <body>
    
    <div class=\"row\">
      <div class=\"large-12 columns\">
      ";
        // line 15
        echo (isset($context["content"]) ? $context["content"] : null);
        echo "
      </div>
    </div>
    
   
    <script src=\"js/jquery.js\"></script>
    <script src=\"js/foundation.min.js\"></script>
    <script>
      \$(document).foundation();
    </script>
  </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "/views//layouts/main.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  35 => 15,  19 => 1,);
    }
}
